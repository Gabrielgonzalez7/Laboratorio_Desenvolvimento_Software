package com.example.projetoaula_04_11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoAula0411ApplicationTests {

    @Test
    void contextLoads() {
    }

}

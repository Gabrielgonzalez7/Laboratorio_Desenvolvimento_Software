package com.example.projetoaula_04_11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoAula0411Application {

    public static void main(String[] args) {
        SpringApplication.run(ProjetoAula0411Application.class, args);
        System.out.println("ProjetoAula0411Application");

    }

}

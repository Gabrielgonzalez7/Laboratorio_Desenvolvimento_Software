module org.example.aula_18_11 {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.aula_18_11 to javafx.fxml;
    exports org.example.aula_18_11;
}
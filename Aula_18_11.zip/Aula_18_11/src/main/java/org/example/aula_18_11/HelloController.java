package org.example.aula_18_11;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class HelloController {
    @FXML
    private Label welcomeText;
    @FXML
    private Label lblNome;
    @FXML
    private TextField txtNome;
    @FXML
    private TextField txtSobrenome;
    @FXML
    private Label lblSobrenome;
    @FXML
    private Label lblNomeCompleto;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }
        @FXML
        protected void OnMostrarNome () {
            String nome;
            nome = txtNome.getText();
            lblNome.setText(nome);
            lblSobrenome.setText(txtSobrenome.getText());

            lblNomeCompleto.setText(txtNome.getText() + " " + txtSobrenome.getText());

    }
}
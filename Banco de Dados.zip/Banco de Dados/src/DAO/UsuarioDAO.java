/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author matheus
 */
public class UsuarioDAO {
        private Conexao conexao;

    public UsuarioDAO(Conexao conexao) {
        this.conexao = new Conexao();
    }

    UsuarioDAO() {
        this.conexao = new Conexao();
    }
    
public boolean salvarUsuario(String nome, String sexo, String idioma) throws SQLException {
    Connection conn = conexao.getConexao();
    String sql = "INSERT INTO usuarios (nome, sexo, idioma) VALUES (?, ?, ?)";
    PreparedStatement stmt = conn.prepareStatement(sql);
    
    stmt.setString(1, nome);
    stmt.setString(2, sexo);
    stmt.setString(3, idioma);
    
    int linhasAfetadas = stmt.executeUpdate();
    stmt.close();
    conn.close();
    
    return linhasAfetadas > 0;
}
        
}

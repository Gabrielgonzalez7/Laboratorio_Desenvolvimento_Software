package DAO;

import beans.Pessoa;
import conexao.Conexao;
import java.awt.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.*;

public class PessoaDAO2 {
    private Conexao conexao;
    private Connection conn;
    private String id;
    private String nome;

    public PessoaDAO2() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }

    public Pessoa getPessoa(int id) throws SQLException {
        String sql = "SELECT * FROM pessoa";
        try {
            PreparedStatement stmt = conn.prepareStatement(
                sql, 
                ResultSet.TYPE_SCROLL_INSENSITIVE, 
                ResultSet.CONCUR_UPDATABLE
            );
            
            ResultSet rs = stmt.executeQuery();
            List<Pessoa> listaPessoas = new ArrayList();
            while(rs.first()) {
                Pessoa p = new Pessoa();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setSexo(rs.getString("sexo"));
                p.setIdioma(rs.getString("idioma"));
                listaPessoas.add(p);
            }
            return listaPessoas;
        } catch (SQLException ex){
            System.out.println("Erro ao consultar todas as pessoas" +ex.getMessage());
            return null;
        }
            
    }
    
    public void editar(Pessoa pessoa){
        try{
            String sql = "UPDATE pessoa set nome=?, sexo=?, idioma=? WHERE id=?";
                    
                    PreparedStatement stmt = conn.prepareStatement(sql);
                    stmt.setString(1, pessoa.getNome());
                    stmt.setString(2, pessoa.getSexo());
                    stmt.setString(3, pessoa.getIdioma());
                    stmt.setInt(4, pessoa.getId());
                    stmt.execute();
                    
        }
        catch(SQLException ex){
            System.out.println("Erro ao atualizar pessoa: "+ex.getMessage());
        }
    }
    public void excluir(int id){
        try{
            String sql = "delete from pessoa WHERE id=?";
            
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
        }
        catch (SQLException ex){
            System.out.println("Erro ao atualizar");
        }
    }
    public String toString(){
        return this.id+ " - "+this.nome;
    }
    }


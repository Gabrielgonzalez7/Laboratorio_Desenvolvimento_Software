package DAO;

import beans.Pessoa;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PessoaDAO {
    private Conexao conexao;
    private Connection conn;
    
    public PessoaDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    public void inserir(Pessoa pessoa) {
        if (this.conn == null) {
            System.out.println("❌ ERRO: Conexão é nula!");
            return;
        }
        
        String sql = "INSERT INTO pessoa (nome, sexo, idioma) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = this.conn.prepareStatement(sql)) {
            stmt.setString(1, pessoa.getNome());
            stmt.setString(2, pessoa.getSexo());
            stmt.setString(3, pessoa.getIdioma());
            stmt.execute();
            System.out.println("✅ Pessoa inserida com sucesso!");
        } catch (SQLException ex) {
            System.out.println("❌ Erro ao inserir: " + ex.getMessage());
        }
    }
    
    public void listarTodos() {
        if (this.conn == null) return;
        
        try {
            String sql = "SELECT * FROM pessoa";
            try (PreparedStatement stmt = this.conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {
                
                System.out.println("=== LISTA DE PESSOAS ===");
                while (rs.next()) {
                    System.out.println("ID: " + rs.getInt("id") +
                                     ", Nome: " + rs.getString("nome") +
                                     ", Sexo: " + rs.getString("sexo") +
                                     ", Idioma: " + rs.getString("idioma"));
                }
            }
        } catch (SQLException ex) {
            System.out.println("Erro ao listar: " + ex.getMessage());
        }
    }
}
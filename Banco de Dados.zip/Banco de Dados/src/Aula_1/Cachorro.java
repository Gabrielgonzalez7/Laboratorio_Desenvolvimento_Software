package Aula_1;

public class Cachorro extends Animal{
    private String raca;


    public String latir(){
        return "Au Au Au!";
    }

}

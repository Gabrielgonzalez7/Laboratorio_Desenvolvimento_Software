package Aula_1;

public class FormaGeometrica {

    public double CalcularArea(){
        System.out.println("Calculando...");
        return 0;
    }



}

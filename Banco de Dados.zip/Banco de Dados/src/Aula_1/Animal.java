package Aula_1;

public class Animal {
    private String nome;
    private int idade;
    private String som;


}

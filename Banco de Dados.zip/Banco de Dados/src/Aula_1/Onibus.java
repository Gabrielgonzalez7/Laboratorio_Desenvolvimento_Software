package Aula_1;

public class Onibus extends Carro{
    protected String modelo;

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }


}

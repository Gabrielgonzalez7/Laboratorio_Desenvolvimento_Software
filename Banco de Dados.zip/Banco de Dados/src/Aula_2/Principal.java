package Aula_2;

public class Principal {
    public static void main(String[] args) {
    Triangulo t = new Triangulo();
    }
}

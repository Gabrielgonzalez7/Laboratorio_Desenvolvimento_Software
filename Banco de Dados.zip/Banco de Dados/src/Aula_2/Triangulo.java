package Aula_2;

public class Triangulo extends FormaGeometrica{

    @Override
    public double calcularArea (){
        double h = 8 , b = 7 , a = 0;
        return a = (b*h)/2;
    }


    }


package Aula_2;

abstract class FormaGeometrica {

    abstract double calcularArea();

}

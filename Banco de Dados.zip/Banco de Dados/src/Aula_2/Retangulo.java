package Aula_2;

public class Retangulo extends FormaGeometrica{

    @Override
    public double calcularArea (){
        double h = 8 , b = 7 , a = 0;
        return a = b*h;
    }
}

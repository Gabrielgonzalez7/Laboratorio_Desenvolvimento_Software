package Principal;

import DAO.PessoaDAO;

public class Main {
    public static void main(String[] args) {
    PessoaDAO pDAO = new PessoaDAO();
    

    
    // LISTAR TODAS AS PESSOAS 👇
    pDAO.listarTodos();
    }
}
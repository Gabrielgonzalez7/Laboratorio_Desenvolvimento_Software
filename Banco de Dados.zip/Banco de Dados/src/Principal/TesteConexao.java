/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Principal;

import conexao.Conexao;
import java.sql.Connection;

/**
 *
 * @author matheus
 */
public class TesteConexao {
    public static void main(String[] args) {
        
    Conexao conexao = new Conexao();
    Connection conn = conexao.getConexao();
    
    if(conn != null){
    System.out.println("Conexão estabelecida com sucesso!");
}
    else{
    System.out.println("Falha na conexão!");
}
}
}